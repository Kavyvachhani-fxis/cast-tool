
# CAST AutoSec

A pip-installable tool to bootstrap and run an automated DevSecOps pipeline (Dependency-Check, Trivy, ZAP, SonarQube) and generate a unified PDF report.
